import React from 'react'

export default function Header() {
  return (
    <>
        {/* Start Header */}
        <h1 style={{ 'backgroundColor' : 'black', 'color' : 'white' }}>Header</h1>
        
    </>
  )
}
