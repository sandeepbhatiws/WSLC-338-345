import React from 'react'
import Footer from './Components/Footer'

export default function Home() {
  return (
    <div>
      Home Page Welcome
      <Footer/>
    </div>
  )
}
