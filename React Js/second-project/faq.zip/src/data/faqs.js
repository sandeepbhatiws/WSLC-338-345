var faqs = [
    {
        userId: 1,
        id: 1,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
    {
        userId: 1,
        id: 2,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
    {
        userId: 1,
        id: 3,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
    {
        userId: 1,
        id: 4,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
    {
        userId: 1,
        id: 5,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
    {
        userId: 1,
        id: 6,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
    {
        userId: 1,
        id: 7,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
    {
        userId: 1,
        id: 8,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
    {
        userId: 1,
        id: 9,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
    {
        userId: 1,
        id: 10,
        title: "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        body: "quia et suscipit suscipit recusandae consequuntur expedita et cum     reprehenderit molestiae ut ut quas totam   nostrum rerum est autem sunt rem veniet architecto"
    },
]

export default faqs;