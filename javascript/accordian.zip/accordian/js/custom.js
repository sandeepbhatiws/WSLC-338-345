
// document.getElementById('question').addEventListener('click',(event)=> {
//     // console.log(event.target.parentNode);
//     console.log(event.target.parentElement);
// });

document.getElementById('questionChild').addEventListener('click',(event)=> {
    // console.log(event.target.childNodes[2]);

    // console.log(document.getElementById('question').parentNode);
    // console.log(document.getElementById('question').parentElement);     // That will use
    // console.log(document.getElementById('questionChild').childNodes);
    // console.log(document.getElementById('questionChild').children[0].innerHTML); // That will use

    // console.log(document.getElementById('row').firstChild);
    // console.log(document.getElementById('row').lastChild);

    // console.log(document.getElementById('row').firstElementChild);   // That will use
    console.log(document.getElementById('row').lastElementChild);   // That will use


});